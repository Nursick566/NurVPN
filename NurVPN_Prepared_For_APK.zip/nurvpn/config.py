# Конфигурация NurVPN для инструментов сборки и публикации.
APP_NAME = "NurVPN"
APP_TAGLINE = "Твой дом в кармане"
AUTHOR_NAME = "Nursick56"
AUTHOR_TG = "https://t.me/repubr"
AUTHOR_EMAIL = "repubr-comparison-AI@mail.ru"

# Репозиторий ещё не создан; заполнить после публикации.
GITHUB_REPO = "Nursick566/nurvpn"

APP_VERSION = "1.0.0"
VERSION_CODE = 1
