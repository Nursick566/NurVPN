#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GRADLE_VERSION="9.5.0"
CACHE_DIR="${HOME}/.cache/nurvpn-gradle"
SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"

if ! command -v java >/dev/null 2>&1; then
  echo "Ошибка: Java не найдена. Установи JDK 21."
  exit 1
fi

JAVA_MAJOR="$(java -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')"
if [[ -z "${JAVA_MAJOR}" || "${JAVA_MAJOR}" -lt 21 ]]; then
  echo "Ошибка: для этой сборки требуется JDK 21 или новее."
  exit 1
fi

if [[ -z "${SDK_DIR}" || ! -d "${SDK_DIR}/platforms/android-37" ]]; then
  echo "Ошибка: Android SDK с платформой API 37 не найден."
  echo "Установи Android SDK API 37 и задай ANDROID_HOME или ANDROID_SDK_ROOT."
  exit 1
fi

export ANDROID_HOME="${SDK_DIR}"

if command -v gradle >/dev/null 2>&1; then
  GRADLE_BIN="$(command -v gradle)"
else
  if ! command -v curl >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then
    echo "Ошибка: для загрузки Gradle требуются curl и unzip."
    exit 1
  fi
  mkdir -p "${CACHE_DIR}"
  GRADLE_HOME_DIR="${CACHE_DIR}/gradle-${GRADLE_VERSION}"
  if [[ ! -x "${GRADLE_HOME_DIR}/bin/gradle" ]]; then
    ARCHIVE="${CACHE_DIR}/gradle-${GRADLE_VERSION}-bin.zip"
    echo "Загружается Gradle ${GRADLE_VERSION}."
    curl -fL --retry 3 \
      "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" \
      -o "${ARCHIVE}"
    unzip -q -o "${ARCHIVE}" -d "${CACHE_DIR}"
  fi
  GRADLE_BIN="${GRADLE_HOME_DIR}/bin/gradle"
fi

cd "${ROOT_DIR}"
"${GRADLE_BIN}" --no-daemon --stacktrace :app:assembleDebug

APK_SOURCE="${ROOT_DIR}/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "${APK_SOURCE}" ]]; then
  echo "Ошибка: Gradle завершился, но APK не найден по ожидаемому пути."
  exit 1
fi

mkdir -p "${ROOT_DIR}/dist"
cp "${APK_SOURCE}" "${ROOT_DIR}/dist/NurVPN-1.0.0-debug.apk"
echo "APK создан: ${ROOT_DIR}/dist/NurVPN-1.0.0-debug.apk"
