package com.nursick56.nurvpn.db

import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

class DatabaseInitializer : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        db.execSQL("INSERT OR REPLACE INTO schema_version(version) VALUES (2)")
        db.execSQL(
            "INSERT OR IGNORE INTO settings(id, role, theme, language, first_launch) " +
                "VALUES (1, '', 'system', 'ru', 1)"
        )
    }
}
