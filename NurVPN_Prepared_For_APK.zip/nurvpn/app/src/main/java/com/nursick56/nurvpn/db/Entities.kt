package com.nursick56.nurvpn.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "schema_version")
data class SchemaVersionEntity(
    @PrimaryKey @ColumnInfo(name = "version") val version: Int
)

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val role: String = "",
    val theme: String = "system",
    val language: String = "ru",
    @ColumnInfo(name = "first_launch") val firstLaunch: Boolean = true
)

@Entity(tableName = "host_config")
data class HostConfigEntity(
    @PrimaryKey val id: Int = 1,
    @ColumnInfo(name = "host_name") val hostName: String,
    @ColumnInfo(name = "host_password_hash") val hostPasswordHash: String,
    @ColumnInfo(name = "host_password_salt") val hostPasswordSalt: String,
    @ColumnInfo(name = "lan_ip") val lanIp: String = "",
    @ColumnInfo(name = "allow_wifi") val allowWifi: Boolean = true,
    @ColumnInfo(name = "allow_bluetooth") val allowBluetooth: Boolean = true,
    @ColumnInfo(name = "allow_internet") val allowInternet: Boolean = false,
    @ColumnInfo(name = "global_stop") val globalStop: Boolean = false,
    val protection: String = "simple",
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "default_rate_down") val defaultRateDown: Int? = null,
    @ColumnInfo(name = "default_rate_up") val defaultRateUp: Int? = null,
    @ColumnInfo(name = "restrict_home_only") val restrictHomeOnly: Boolean = false,
    @ColumnInfo(name = "per_app_enabled") val perAppEnabled: Boolean = false,
    @ColumnInfo(name = "per_app_list") val perAppList: String = "[]"
)

@Entity(tableName = "host_keys")
data class HostKeysEntity(
    @PrimaryKey val id: Int = 1,
    @ColumnInfo(name = "private_key") val privateKeyEncrypted: String,
    @ColumnInfo(name = "public_key") val publicKey: String,
    @ColumnInfo(name = "listen_port") val listenPort: Int
)

@Entity(
    tableName = "peers",
    indices = [
        Index(value = ["internal_ip"], unique = true),
        Index(value = ["pubkey"], unique = true)
    ]
)
data class PeerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    @ColumnInfo(name = "internal_ip") val internalIp: String,
    @ColumnInfo(name = "pubkey") val pubKey: String? = null,
    @ColumnInfo(name = "privkey") val privateKeyEncrypted: String? = null,
    @ColumnInfo(name = "allowed_ips") val allowedIps: String = "",
    val enabled: Boolean = true,
    val blocked: Boolean = false,
    @ColumnInfo(name = "blocked_at") val blockedAt: Long? = null,
    @ColumnInfo(name = "blocked_reason") val blockedReason: String? = null,
    @ColumnInfo(name = "rate_down_mbit") val rateDownMbit: Int? = null,
    @ColumnInfo(name = "rate_up_mbit") val rateUpMbit: Int? = null,
    @ColumnInfo(name = "rx_bytes_session") val rxBytesSession: Long = 0,
    @ColumnInfo(name = "tx_bytes_session") val txBytesSession: Long = 0,
    @ColumnInfo(name = "last_handshake") val lastHandshake: Long? = null,
    @ColumnInfo(name = "expires_at") val expiresAt: Long? = null,
    val note: String = "",
    @ColumnInfo(name = "created_at") val createdAt: Long
)

@Entity(tableName = "consumer_config")
data class ConsumerConfigEntity(
    @PrimaryKey val id: Int = 1,
    @ColumnInfo(name = "host_name") val hostName: String = "",
    @ColumnInfo(name = "host_endpoint") val hostEndpoint: String = "",
    @ColumnInfo(name = "host_password_ref") val hostPasswordRef: String = "",
    val protection: String = "simple",
    @ColumnInfo(name = "last_connected") val lastConnected: Long? = null
)

@Entity(tableName = "audit")
data class AuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ts: Long,
    val event: String,
    val actor: String,
    val ip: String,
    val details: String
)
