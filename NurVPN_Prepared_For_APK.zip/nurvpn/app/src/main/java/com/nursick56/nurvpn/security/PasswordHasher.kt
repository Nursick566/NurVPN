package com.nursick56.nurvpn.security

import com.nursick56.nurvpn.config.AppConfig
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class PasswordDigest(val saltBase64: String, val hashBase64: String)

object PasswordHasher {
    private val random = SecureRandom()

    fun create(password: CharArray): PasswordDigest {
        require(password.size >= 10) { "Пароль должен содержать не менее 10 символов." }
        val salt = ByteArray(AppConfig.PASSWORD_SALT_BYTES).also(random::nextBytes)
        val hash = derive(password, salt)
        return PasswordDigest(
            Base64.getEncoder().encodeToString(salt),
            Base64.getEncoder().encodeToString(hash)
        )
    }

    fun verify(password: CharArray, saltBase64: String, hashBase64: String): Boolean {
        return try {
            val salt = Base64.getDecoder().decode(saltBase64)
            val expected = Base64.getDecoder().decode(hashBase64)
            MessageDigest.isEqual(derive(password, salt), expected)
        } catch (_: IllegalArgumentException) {
            false
        }
    }

    private fun derive(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, AppConfig.PBKDF2_ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec)
                .encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun generateOneTimePassword(byteCount: Int = 10): String {
        val bytes = ByteArray(byteCount).also(random::nextBytes)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    }
}
