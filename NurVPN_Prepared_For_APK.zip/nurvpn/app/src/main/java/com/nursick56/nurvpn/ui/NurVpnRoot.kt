package com.nursick56.nurvpn.ui

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nursick56.nurvpn.config.AppConfig
import com.nursick56.nurvpn.NurVpnApplication
import com.nursick56.nurvpn.db.SettingsEntity
import com.nursick56.nurvpn.db.HostConfigEntity
import com.nursick56.nurvpn.security.PasswordHasher
import com.nursick56.nurvpn.security.SecretStore
import com.nursick56.nurvpn.updater.GitHubUpdateChecker
import com.nursick56.nurvpn.R
import kotlinx.coroutines.launch

private val Bg = Color(0xFF0A0710)
private val Panel = Color(0xFF140F1F)
private val CardColor = Color(0xFF1A1329)
private val Border = Color(0xFF2A1F3D)
private val MainText = Color(0xFFEFEAFF)
private val Muted = Color(0xFF9A8DB8)
private val Accent = Color(0xFF8B5CF6)
private val AccentHover = Color(0xFFA78BFA)
private val Danger = Color(0xFFF87171)
private val Success = Color(0xFF34D399)
private val Warning = Color(0xFFFBBF24)

private enum class AppScreen {
    ROLE, HOST_WIZARD, HOST_HOME, CONSUMER_HOME, SETTINGS, SETTINGS_SECTION, ABOUT
}

@Composable
fun NurVpnRoot() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nurvpn_ui", Context.MODE_PRIVATE) }
    val database = remember { (context.applicationContext as NurVpnApplication).database }
    val rootScope = rememberCoroutineScope()
    var role by rememberSaveable {
        mutableStateOf(prefs.getString("role", "") ?: "")
    }
    var screen by rememberSaveable {
        mutableStateOf(
            when (role) {
                "host" -> AppScreen.HOST_HOME.name
                "consumer" -> AppScreen.CONSUMER_HOME.name
                else -> AppScreen.ROLE.name
            }
        )
    }
    var previousSettingsScreen by rememberSaveable { mutableStateOf(AppScreen.HOST_HOME.name) }
    var selectedSection by rememberSaveable { mutableStateOf("Хост") }

    fun setRole(value: String) {
        role = value
        prefs.edit().putString("role", value).apply()
        rootScope.launch {
            database.settingsDao().save(
                SettingsEntity(
                    role = value,
                    theme = "system",
                    language = "ru",
                    firstLaunch = value.isBlank()
                )
            )
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Bg
    ) {
        when (AppScreen.valueOf(screen)) {
            AppScreen.ROLE -> RoleSelectScreen(
                onHost = {
                    setRole("host")
                    screen = AppScreen.HOST_WIZARD.name
                },
                onConsumer = {
                    setRole("consumer")
                    screen = AppScreen.CONSUMER_HOME.name
                }
            )
            AppScreen.HOST_WIZARD -> HostWizardScreen(
                onFinished = {
                    screen = AppScreen.HOST_HOME.name
                },
                onBack = {
                    setRole("")
                    screen = AppScreen.ROLE.name
                }
            )
            AppScreen.HOST_HOME -> HostHomeScreen(
                onSettings = {
                    previousSettingsScreen = AppScreen.HOST_HOME.name
                    screen = AppScreen.SETTINGS.name
                }
            )
            AppScreen.CONSUMER_HOME -> ConsumerHomeScreen(
                onSettings = {
                    previousSettingsScreen = AppScreen.CONSUMER_HOME.name
                    screen = AppScreen.SETTINGS.name
                }
            )
            AppScreen.SETTINGS -> SettingsScreen(
                role = role,
                onBack = { screen = previousSettingsScreen },
                onOpenSection = {
                    selectedSection = it
                    screen = AppScreen.SETTINGS_SECTION.name
                },
                onAbout = { screen = AppScreen.ABOUT.name },
                onRoleChanged = { newRole ->
                    setRole(newRole)
                    screen = if (newRole == "host") AppScreen.HOST_WIZARD.name
                    else AppScreen.CONSUMER_HOME.name
                }
            )
            AppScreen.SETTINGS_SECTION -> SettingsSectionScreen(
                section = selectedSection,
                role = role,
                onBack = { screen = AppScreen.SETTINGS.name }
            )
            AppScreen.ABOUT -> AboutScreen(
                onBack = { screen = if (previousSettingsScreen == AppScreen.CONSUMER_HOME.name ||
                    previousSettingsScreen == AppScreen.HOST_HOME.name) AppScreen.SETTINGS.name
                    else AppScreen.SETTINGS.name }
            )
        }
    }
}

@Composable
private fun Page(
    title: String,
    modifier: Modifier = Modifier,
    headerAction: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Bg)
            .padding(
                start = 20.dp,
                end = 20.dp,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 16.dp
            )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, color = MainText, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            headerAction?.invoke()
        }
        Spacer(Modifier.height(20.dp))
        content()
    }
}

@Composable
private fun LogoHeader() {
    val context = LocalContext.current
    val logoBitmap = remember {
        context.assets.open("logo.png").use { stream ->
            BitmapFactory.decodeStream(stream).asImageBitmap()
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            bitmap = logoBitmap,
            contentDescription = "Логотип NurVPN",
            modifier = Modifier.size(54.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text("NurVPN", color = MainText, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Text(AppConfig.APP_TAGLINE, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun RoleSelectScreen(
    onHost: () -> Unit,
    onConsumer: () -> Unit
) {
    Page(title = "") {
        Spacer(Modifier.height(22.dp))
        LogoHeader()
        Spacer(Modifier.height(40.dp))
        Text("Выбери роль", color = MainText, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Text("На этом устройстве активна только одна роль.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        RoleCard(
            title = "Хост",
            description = "Настройка локального профиля",
            materialIcon = Icons.Default.Router,
            onClick = onHost
        )
        Spacer(Modifier.height(14.dp))
        RoleCard(
            title = "Потребитель",
            description = "Подключение к уже настроенному хосту",
            icon = painterResource(R.drawable.user),
            onClick = onConsumer
        )
        Spacer(Modifier.weight(1f))
        Text(
            "NurVPN 1.0.0",
            color = Muted,
            fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun RoleCard(
    title: String,
    description: String,
    icon: Painter? = null,
    materialIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardColor),
        border = BorderStroke(1.dp, Border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Image(icon, contentDescription = null, modifier = Modifier.size(44.dp))
            } else if (materialIcon != null) {
                androidx.compose.material3.Icon(
                    materialIcon,
                    contentDescription = null,
                    tint = Accent,
                    modifier = Modifier.size(40.dp)
                )
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(description, color = Muted, fontSize = 13.sp)
            }
            Image(
                painter = painterResource(R.drawable.arrow_right),
                contentDescription = "Открыть",
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun HostWizardScreen(onFinished: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val wizardScope = rememberCoroutineScope()
    val database = remember { (context.applicationContext as NurVpnApplication).database }
    var step by rememberSaveable { mutableStateOf(1) }
    var hostName by rememberSaveable { mutableStateOf("Мой NurVPN") }
    var password by rememberSaveable { mutableStateOf(PasswordHasher.generateOneTimePassword(14)) }
    var showPassword by rememberSaveable { mutableStateOf(false) }
    var allowWifi by rememberSaveable { mutableStateOf(true) }
    var allowBluetooth by rememberSaveable { mutableStateOf(true) }
    var allowInternet by rememberSaveable { mutableStateOf(false) }
    var protection by rememberSaveable { mutableStateOf("simple") }
    var error by rememberSaveable { mutableStateOf("") }

    Page(title = "Настройка хоста") {
        Text("Шаг $step из 4", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier.fillMaxWidth().height(4.dp)
                .background(Border, RoundedCornerShape(4.dp))
        ) {
            Box(
                modifier = Modifier.fillMaxWidth(step / 4f).height(4.dp)
                    .background(Accent, RoundedCornerShape(4.dp))
            )
        }
        Spacer(Modifier.height(24.dp))
        when (step) {
            1 -> {
                Text("Название хоста", color = MainText, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = hostName,
                    onValueChange = { hostName = it; error = "" },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Название") }
                )
            }
            2 -> {
                Text("Пароль доступа", color = MainText, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("Минимум 10 символов. Для лучшей защиты используй 12 или больше.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; error = "" },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Пароль") },
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        Image(
                            painter = painterResource(if (showPassword) R.drawable.eye_hide else R.drawable.eye),
                            contentDescription = if (showPassword) "Скрыть пароль" else "Показать пароль",
                            modifier = Modifier.size(24.dp).clickable { showPassword = !showPassword }
                        )
                    }
                )
                Spacer(Modifier.height(10.dp))
                SecondaryIconAction("Сгенерировать пароль") {
                    password = PasswordHasher.generateOneTimePassword(14)
                }
                SecondaryAction("Скопировать пароль", R.drawable.copy) {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("NurVPN", password))
                }
            }
            3 -> {
                Text("Способы подключения", color = MainText, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Wi-Fi", allowWifi, R.drawable.wifi) { allowWifi = it }
                SettingSwitch("Bluetooth", allowBluetooth, R.drawable.bluetooth) { allowBluetooth = it }
                SettingSwitch("Интернет", allowInternet, R.drawable.internet) { allowInternet = it }
                Spacer(Modifier.height(12.dp))
                InfoPanel("Интернет-режим требует доступного белого IP. При CGNAT прямое входящее подключение обычно недоступно.", warning = true)
            }
            4 -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.shield), contentDescription = "Защита", modifier = Modifier.size(23.dp))
                    Spacer(Modifier.width(9.dp))
                    Text("Профиль защиты", color = MainText, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                }
                ProtectionOption("Простой", "Базовый профиль без активного туннеля в этой сборке", "simple", protection) { protection = it }
                ProtectionOption("Усиленный", "Расширенный сетевой профиль не активен в этой сборке", "enhanced", protection) { protection = it }
                ProtectionOption("Максимальная конфиденциальность", "Расширенные параметры требуют отдельной интеграции движка", "maximum", protection) { protection = it }
            }
        }
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(error, color = Danger, fontSize = 13.sp)
        }
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            if (step == 1) {
                SecondaryButton("Отмена", Modifier.weight(1f), onBack)
            } else {
                SecondaryButton("Назад", Modifier.weight(1f)) { step -= 1 }
            }
            GlowButton(
                text = if (step == 4) "Создать профиль" else "Продолжить",
                modifier = Modifier.weight(1f)
            ) {
                if (step == 1 && hostName.isBlank()) {
                    error = "Укажи название хоста."
                } else if (step == 2 && password.length < 10) {
                    error = "Пароль должен содержать не менее 10 символов."
                } else if (step < 4) {
                    step += 1
                } else {
                    try {
                        val digest = PasswordHasher.create(password.toCharArray())
                        SecretStore(context).apply {
                            putString("host_password_salt", digest.saltBase64)
                            putString("host_password_hash", digest.hashBase64)
                            putString("host_name", hostName)
                            putString("host_protection", protection)
                        }
                        wizardScope.launch {
                            try {
                                database.hostConfigDao().save(
                                    HostConfigEntity(
                                        hostName = hostName,
                                        hostPasswordHash = digest.hashBase64,
                                        hostPasswordSalt = digest.saltBase64,
                                        allowWifi = allowWifi,
                                        allowBluetooth = allowBluetooth,
                                        allowInternet = allowInternet,
                                        protection = protection,
                                        createdAt = System.currentTimeMillis()
                                    )
                                )
                                context.getSharedPreferences("nurvpn_ui", Context.MODE_PRIVATE)
                                    .edit().putString("host_name", hostName).apply()
                                onFinished()
                            } catch (saveError: Exception) {
                                error = saveError.message ?: "Не удалось сохранить профиль хоста."
                            }
                        }
                    } catch (e: Exception) {
                        error = e.message ?: "Не удалось сохранить настройки."
                    }
                }
            }
        }
    }
}

@Composable
private fun HostHomeScreen(onSettings: () -> Unit) {
    val context = LocalContext.current
    val name = remember {
        context.getSharedPreferences("nurvpn_ui", Context.MODE_PRIVATE)
            .getString("host_name", "Мой NurVPN") ?: "Мой NurVPN"
    }
    var stopNewConnections by rememberSaveable { mutableStateOf(false) }
    var showAddDialog by rememberSaveable { mutableStateOf(false) }

    Page(
        title = "NurVPN",
        headerAction = {
            Image(
                painter = painterResource(R.drawable.settings),
                contentDescription = "Настройки",
                modifier = Modifier.size(26.dp).clickable(onClick = onSettings)
            )
        }
    ) {
        Text(name, color = MainText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Профиль сохранён. Сетевой узел ещё не активен.", color = Warning, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricImageCard("Устройств", "0", R.drawable.devices, Modifier.weight(1f))
            MetricImageCard("Трафик сессии", "0 Б", R.drawable.speed, Modifier.weight(1f))
            MetricCard("Нагрузка", "Нет данных", Icons.Default.Memory, Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Panel),
            border = BorderStroke(1.dp, Border),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Все подключения", color = MainText, fontWeight = FontWeight.SemiBold)
                Text(
                    "Остановка будет применяться к новым подключениям после запуска сетевого узла.",
                    color = Muted,
                    fontSize = 12.sp
                )
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painterResource(if (stopNewConnections) R.drawable.pause else R.drawable.play),
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(if (stopNewConnections) "СТОП включён" else "СТОП выключен", color = if (stopNewConnections) Danger else Success)
                    }
                    Switch(checked = stopNewConnections, onCheckedChange = { stopNewConnections = it })
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Пользователи", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        InfoPanel("Список появится после подключения рабочего VPN-узла и регистрации устройств.")
        Spacer(Modifier.height(12.dp))
        GlowButtonWithIcon("Добавить пользователя", R.drawable.plus, Modifier.fillMaxWidth()) {
            showAddDialog = true
        }
        Spacer(Modifier.height(12.dp))
        InfoPanel("mDNS, BLE, выдача конфигураций и пересылка трафика хоста в этой сборке ещё не активированы.")
    }
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Добавление пользователя") },
            text = { Text("Пока нельзя безопасно создать peer или выдать рабочий .conf: сетевой узел и привязка ключей ещё не реализованы.") },
            confirmButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Понятно") }
            },
            containerColor = CardColor
        )
    }
}

@Composable
private fun ConsumerHomeScreen(onSettings: () -> Unit) {
    var address by rememberSaveable { mutableStateOf("") }
    var showManual by rememberSaveable { mutableStateOf(false) }
    Page(
        title = "NurVPN",
        headerAction = {
            Image(
                painter = painterResource(R.drawable.settings),
                contentDescription = "Настройки",
                modifier = Modifier.size(26.dp).clickable(onClick = onSettings)
            )
        }
    ) {
        LogoHeader()
        Spacer(Modifier.height(26.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.search), contentDescription = "Поиск", modifier = Modifier.size(23.dp))
            Spacer(Modifier.width(9.dp))
            Text("Ищем хосты рядом...", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("Автоматический поиск появится после подключения сервисов обнаружения.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        InfoPanel("Пока ни один доступный хост не найден.")
        Spacer(Modifier.height(14.dp))
        SecondaryButton("Ввести адрес вручную", Modifier.fillMaxWidth()) { showManual = !showManual }
        if (showManual) {
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("IP-адрес или имя хоста") }
            )
            Spacer(Modifier.height(10.dp))
            GlowButton("Продолжить", Modifier.fillMaxWidth()) {
                showManual = false
            }
            Text(
                "Сетевое подключение пока недоступно в этой сборке.",
                color = Warning,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.weight(1f))
        InfoPanel("Для подключения потребуется рабочий VPN-движок, пароль-приглашение и конфигурация хоста.")
    }
}

@Composable
private fun SettingsScreen(
    role: String,
    onBack: () -> Unit,
    onOpenSection: (String) -> Unit,
    onAbout: () -> Unit,
    onRoleChanged: (String) -> Unit
) {
    var askRoleChange by rememberSaveable { mutableStateOf(false) }
    val sections = if (role == "host") {
        listOf("Роль", "Хост", "Подключение", "Разрешения (для всех)", "Защита", "Заблокированные (0)", "Внешний вид", "О приложении")
    } else {
        listOf("Роль", "Хост", "Внешний вид", "О приложении")
    }
    Page(
        title = "Настройки",
        headerAction = { BackIcon(onBack) }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            sections.forEach { section ->
                SettingsRow(section) {
                    if (section == "О приложении") onAbout()
                    else if (section == "Роль") askRoleChange = true
                    else onOpenSection(section)
                }
            }
        }
    }
    if (askRoleChange) {
        AlertDialog(
            onDismissRequest = { askRoleChange = false },
            title = { Text("Сменить роль?") },
            text = { Text("Текущая сессия будет остановлена. Сохранённые данные останутся на устройстве.") },
            confirmButton = {
                TextButton(onClick = {
                    askRoleChange = false
                    onRoleChanged(if (role == "host") "consumer" else "host")
                }) { Text("Продолжить", color = Danger) }
            },
            dismissButton = {
                TextButton(onClick = { askRoleChange = false }) { Text("Отмена") }
            },
            containerColor = CardColor
        )
    }
}

@Composable
private fun SettingsSectionScreen(section: String, role: String, onBack: () -> Unit) {
    Page(
        title = section,
        headerAction = { BackIcon(onBack) }
    ) {
        when {
            section == "Подключение" -> {
                SettingSwitch("Wi-Fi", true, R.drawable.wifi) {}
                SettingSwitch("Bluetooth", true, R.drawable.bluetooth) {}
                SettingSwitch("Интернет", false, R.drawable.internet) {}
                InfoPanel("Интернет-режим требует доступного белого IP. При CGNAT входящее подключение обычно не проходит.")
            }
            section == "Разрешения (для всех)" -> {
                SettingSwitch("Только домашняя сеть", false) {}
                SettingSwitch("Только выбранные приложения", false) {}
                InfoPanel("Скорость по умолчанию: без ограничения. Эти параметры должны применяться только к новым пользователям после реализации сетевого узла.")
            }
            section == "Защита" -> {
                ProtectionOption("Простой", "Базовый профиль без активного туннеля", "simple", "simple") {}
                ProtectionOption("Усиленный", "Расширенный сетевой профиль не активен в этой сборке", "enhanced", "simple") {}
                ProtectionOption("Максимальная конфиденциальность", "Требуется интеграция движка и проверка параметров", "maximum", "simple") {}
                InfoPanel("Смена профиля будет отключать активные подключения после реализации VPN-движка.")
            }
            section.startsWith("Заблокированные") -> {
                InfoPanel("Заблокированных устройств пока нет.")
            }
            section == "Внешний вид" -> {
                Text("Тема", color = MainText, fontWeight = FontWeight.SemiBold)
                Text("Системная", color = Muted)
                Text("Тёмная", color = Muted)
                Text("Светлая", color = Muted)
                Spacer(Modifier.height(14.dp))
                Text("Язык", color = MainText, fontWeight = FontWeight.SemiBold)
                Text("Русский", color = Muted)
            }
            section == "Хост" -> {
                Text("Текущая роль: ${if (role == "host") "Хост" else "Потребитель"}", color = MainText)
                InfoPanel("Изменение пароля, списка устройств и параметров ключей станет доступно после подключения базы данных к интерфейсу.")
            }
            else -> {
                InfoPanel("Раздел будет активирован вместе с соответствующим модулем.")
            }
        }
    }
}

@Composable
private fun AboutScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var checking by rememberSaveable { mutableStateOf(false) }
    var updateMessage by rememberSaveable { mutableStateOf("") }

    Page(title = "О приложении", headerAction = { BackIcon(onBack) }) {
        LogoHeader()
        Spacer(Modifier.height(18.dp))
        Text("Версия ${AppConfig.APP_VERSION}", color = MainText, fontSize = 16.sp)
        Text("Автор: ${AppConfig.AUTHOR_NAME}", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Text("Telegram-канал", color = AccentHover, modifier = Modifier.clickable {
            openExternalLink(context, AppConfig.AUTHOR_TG)
        })
        Text(
            "Почта поддержки: ${AppConfig.AUTHOR_EMAIL}",
            color = AccentHover,
            fontSize = 13.sp,
            modifier = Modifier.clickable {
                openExternalLink(context, "mailto:${AppConfig.AUTHOR_EMAIL}")
            }
        )
        Spacer(Modifier.height(14.dp))
        GlowButton("Проверить обновления", Modifier.fillMaxWidth(), enabled = !checking) {
            checking = true
            updateMessage = ""
            scope.launch {
                val result = GitHubUpdateChecker().checkLatest()
                updateMessage = result.message
                checking = false
            }
        }
        if (checking) {
            Spacer(Modifier.height(12.dp))
            CircularProgressIndicator(color = Accent, strokeCap = StrokeCap.Round)
        }
        if (updateMessage.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(updateMessage, color = Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text("Ограничения", color = MainText, fontWeight = FontWeight.SemiBold)
        Text(
            "Интернет-режим требует белый IP. При CGNAT прямое входящее подключение недоступно. mDNS может блокироваться настройками роутера, тогда потребуется ручной ввод IP. BLE-поиск зависит от устройства и расстояния.",
            color = Muted,
            fontSize = 13.sp
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "Лицензия и исходный код",
            color = AccentHover,
            modifier = Modifier.clickable {
                openExternalLink(context, "https://github.com/${AppConfig.GITHUB_REPO}")
            }
        )
    }
}

@Composable
private fun SettingsRow(title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(Panel, RoundedCornerShape(10.dp))
            .border(1.dp, Border, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = MainText, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Image(
            painter = painterResource(R.drawable.arrow_right),
            contentDescription = "Открыть раздел",
            modifier = Modifier.size(21.dp)
        )
    }
}

@Composable
private fun BackIcon(onClick: () -> Unit) {
    Image(
        painter = painterResource(R.drawable.arrow_left),
        contentDescription = "Назад",
        modifier = Modifier.size(26.dp).clickable(onClick = onClick)
    )
}

@Composable
private fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CardColor),
        border = BorderStroke(1.dp, Border)
    ) {
        Column(Modifier.padding(10.dp)) {
            androidx.compose.material3.Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(8.dp))
            Text(value, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(title, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MetricImageCard(title: String, value: String, iconId: Int, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CardColor),
        border = BorderStroke(1.dp, Border)
    ) {
        Column(Modifier.padding(10.dp)) {
            Image(painterResource(iconId), contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(8.dp))
            Text(value, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(title, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, iconId: Int? = null, onChanged: (Boolean) -> Unit) {
    var value by rememberSaveable(title) { mutableStateOf(checked) }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (iconId != null) {
                Image(painterResource(iconId), contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(9.dp))
            }
            Text(title, color = MainText, fontSize = 15.sp)
        }
        Switch(checked = value, onCheckedChange = {
            value = it
            onChanged(it)
        })
    }
}

@Composable
private fun ProtectionOption(title: String, description: String, value: String, selected: String, onSelected: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onSelected(value) }.padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected == value, onClick = { onSelected(value) })
        Spacer(Modifier.width(8.dp))
        Column {
            Text(title, color = MainText, fontWeight = FontWeight.Medium)
            Text(description, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun InfoPanel(text: String, warning: Boolean = false) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painterResource(if (warning) R.drawable.warning else R.drawable.info),
                contentDescription = if (warning) "Предупреждение" else "Информация",
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(9.dp))
            Text(text, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SecondaryIconAction(text: String, onClick: () -> Unit) {
    Row(
        Modifier.clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        androidx.compose.material3.Icon(
            Icons.Default.Refresh,
            contentDescription = null,
            tint = AccentHover,
            modifier = Modifier.size(19.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(text, color = AccentHover, fontSize = 14.sp)
    }
}

@Composable
private fun SecondaryAction(text: String, iconId: Int, onClick: () -> Unit) {
    Row(
        Modifier.clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(iconId), contentDescription = null, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = AccentHover, fontSize = 14.sp)
    }
}

@Composable
private fun SecondaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Button(
        onClick = onClick,
        modifier = modifier
            .height(48.dp)
            .drawBehind {
                drawRoundRect(
                    color = Accent.copy(alpha = 0.10f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx()),
                    style = Stroke(width = 8.dp.toPx())
                )
            }
            .shadow(
                elevation = 5.dp,
                shape = shape,
                ambientColor = Accent.copy(alpha = 0.18f),
                spotColor = Accent.copy(alpha = 0.18f)
            ),
        shape = shape,
        colors = ButtonDefaults.buttonColors(containerColor = CardColor, contentColor = MainText),
        border = BorderStroke(1.dp, Accent.copy(alpha = 0.45f)),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 1.dp, pressedElevation = 7.dp)
    ) {
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun GlowButtonWithIcon(
    text: String,
    iconId: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(8.dp)
    Button(
        onClick = onClick,
        modifier = modifier
            .height(48.dp)
            .drawBehind {
                drawRoundRect(
                    color = Accent.copy(alpha = 0.20f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx()),
                    style = Stroke(width = 13.dp.toPx())
                )
            }
            .shadow(12.dp, shape, ambientColor = Accent.copy(alpha = 0.42f), spotColor = Accent.copy(alpha = 0.42f))
            .border(1.dp, AccentHover, shape),
        shape = shape,
        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp, pressedElevation = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(iconId), contentDescription = null, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(8.dp))
            Text(text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun GlowButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(8.dp)
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(48.dp)
            .drawBehind {
                if (enabled) {
                    drawRoundRect(
                        color = Accent.copy(alpha = 0.20f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx()),
                        style = Stroke(width = 13.dp.toPx())
                    )
                }
            }
            .shadow(
                elevation = if (enabled) 12.dp else 0.dp,
                shape = shape,
                ambientColor = Accent.copy(alpha = 0.42f),
                spotColor = Accent.copy(alpha = 0.42f)
            )
            .border(1.dp, if (enabled) AccentHover else Border, shape),
        shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = Accent,
            contentColor = Color.White,
            disabledContainerColor = Color(0xFF34294A),
            disabledContentColor = Muted
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 4.dp,
            pressedElevation = 10.dp,
            disabledElevation = 0.dp
        )
    ) {
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun openExternalLink(context: Context, url: String) {
    try {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
        context.startActivity(intent)
    } catch (_: Exception) {
        // Ссылка не открылась; приложение остаётся на текущем экране.
    }
}
