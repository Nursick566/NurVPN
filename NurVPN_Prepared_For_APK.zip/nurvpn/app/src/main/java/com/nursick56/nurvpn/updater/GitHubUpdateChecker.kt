package com.nursick56.nurvpn.updater

import com.nursick56.nurvpn.config.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class UpdateCheckResult(
    val updateAvailable: Boolean,
    val message: String,
    val releaseUrl: String? = null,
    val apkUrl: String? = null
)

class GitHubUpdateChecker {
    private val client = OkHttpClient.Builder()
        .connectTimeout(AppConfig.NETWORK_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(AppConfig.NETWORK_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(AppConfig.NETWORK_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .callTimeout(AppConfig.NETWORK_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .build()

    suspend fun checkLatest(): UpdateCheckResult = withContext(Dispatchers.IO) {
        val url = "https://api.github.com/repos/${AppConfig.GITHUB_REPO}/releases/latest"
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "NurVPN-Android")
            .get()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.code == 404) {
                    return@withContext UpdateCheckResult(
                        updateAvailable = false,
                        message = "Обновлений нет. Репозиторий ещё не опубликован."
                    )
                }
                if (!response.isSuccessful) {
                    return@withContext UpdateCheckResult(
                        updateAvailable = false,
                        message = "Не удалось проверить обновления. Код ответа: ${response.code}."
                    )
                }

                val payload = response.body?.string()
                    ?: return@withContext UpdateCheckResult(false, "GitHub вернул пустой ответ.")
                val json = JSONObject(payload)
                val tag = json.optString("tag_name").removePrefix("v")
                val releaseUrl = json.optString("html_url").takeIf(String::isNotBlank)
                val assets = json.optJSONArray("assets")
                var apkUrl: String? = null
                if (assets != null) {
                    for (index in 0 until assets.length()) {
                        val asset = assets.optJSONObject(index) ?: continue
                        val name = asset.optString("name")
                        if (name.endsWith(".apk", ignoreCase = true)) {
                            apkUrl = asset.optString("browser_download_url").takeIf(String::isNotBlank)
                            break
                        }
                    }
                }

                if (compareVersions(tag, AppConfig.APP_VERSION) > 0) {
                    UpdateCheckResult(
                        updateAvailable = true,
                        message = "Доступна новая версия: $tag. Установка выполняется только после подтверждения пользователя.",
                        releaseUrl = releaseUrl,
                        apkUrl = apkUrl
                    )
                } else {
                    UpdateCheckResult(false, "Установлена последняя опубликованная версия.")
                }
            }
        } catch (_: Exception) {
            UpdateCheckResult(false, "Не удалось связаться с GitHub. Проверь подключение к интернету.")
        }
    }

    private fun compareVersions(first: String, second: String): Int {
        val a = first.split('.').map { it.toIntOrNull() ?: 0 }
        val b = second.split('.').map { it.toIntOrNull() ?: 0 }
        val count = maxOf(a.size, b.size)
        for (i in 0 until count) {
            val left = a.getOrElse(i) { 0 }
            val right = b.getOrElse(i) { 0 }
            if (left != right) return left.compareTo(right)
        }
        return 0
    }
}
