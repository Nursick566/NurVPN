package com.nursick56.nurvpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.nursick56.nurvpn.ui.NurVpnRoot
import com.nursick56.nurvpn.ui.NurVpnTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NurVpnTheme {
                NurVpnRoot()
            }
        }
    }
}
