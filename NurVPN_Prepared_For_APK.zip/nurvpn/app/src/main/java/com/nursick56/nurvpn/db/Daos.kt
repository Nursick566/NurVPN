package com.nursick56.nurvpn.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings WHERE id = 1 LIMIT 1")
    fun observe(): Flow<SettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(value: SettingsEntity)
}

@Dao
interface HostConfigDao {
    @Query("SELECT * FROM host_config WHERE id = 1 LIMIT 1")
    suspend fun get(): HostConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(value: HostConfigEntity)
}

@Dao
interface PeerDao {
    @Query("SELECT * FROM peers ORDER BY created_at DESC")
    fun observeAll(): Flow<List<PeerEntity>>

    @Query("SELECT * FROM peers WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): PeerEntity?

    @Query("SELECT * FROM peers WHERE internal_ip = :ip LIMIT 1")
    suspend fun getByIp(ip: String): PeerEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(value: PeerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun update(value: PeerEntity)

    @Query("DELETE FROM peers WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM peers WHERE blocked = 1")
    fun observeBlockedCount(): Flow<Int>
}

@Dao
interface ConsumerConfigDao {
    @Query("SELECT * FROM consumer_config WHERE id = 1 LIMIT 1")
    suspend fun get(): ConsumerConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(value: ConsumerConfigEntity)
}

@Dao
interface AuditDao {
    @Insert
    suspend fun append(value: AuditEntity)

    @Query("SELECT * FROM audit ORDER BY ts DESC LIMIT :limit")
    suspend fun recent(limit: Int = 100): List<AuditEntity>
}
