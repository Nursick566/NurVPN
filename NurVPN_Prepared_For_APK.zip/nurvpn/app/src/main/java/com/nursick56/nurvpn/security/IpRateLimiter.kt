package com.nursick56.nurvpn.security

import java.util.concurrent.ConcurrentHashMap

class IpRateLimiter(
    private val maxAttempts: Int = 5,
    private val windowMs: Long = 60_000L,
    private val blockMs: Long = 300_000L
) {
    private data class Entry(
        var windowStart: Long,
        var attempts: Int,
        var blockedUntil: Long
    )

    private val entries = ConcurrentHashMap<String, Entry>()

    @Synchronized
    fun registerAttempt(ip: String, nowMs: Long = System.currentTimeMillis()): Boolean {
        val entry = entries[ip]
        if (entry == null) {
            entries[ip] = Entry(nowMs, 1, 0L)
            return true
        }

        if (entry.blockedUntil > nowMs) return false

        if (nowMs - entry.windowStart >= windowMs) {
            entry.windowStart = nowMs
            entry.attempts = 0
            entry.blockedUntil = 0L
        }

        entry.attempts += 1
        if (entry.attempts > maxAttempts) {
            entry.blockedUntil = nowMs + blockMs
            return false
        }
        return true
    }

    @Synchronized
    fun isBlocked(ip: String, nowMs: Long = System.currentTimeMillis()): Boolean {
        val entry = entries[ip] ?: return false
        if (entry.blockedUntil <= nowMs) return false
        return true
    }

    @Synchronized
    fun clearExpired(nowMs: Long = System.currentTimeMillis()) {
        entries.entries.removeAll { (_, value) ->
            value.blockedUntil <= nowMs && nowMs - value.windowStart >= windowMs
        }
    }
}
