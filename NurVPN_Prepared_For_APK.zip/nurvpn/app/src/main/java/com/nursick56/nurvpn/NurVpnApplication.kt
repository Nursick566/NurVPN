package com.nursick56.nurvpn

import android.app.Application
import androidx.room.Room
import com.nursick56.nurvpn.db.AppDatabase
import com.nursick56.nurvpn.db.DatabaseInitializer
import timber.log.Timber

class NurVpnApplication : Application() {
    val database: AppDatabase by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "vpn.db"
        )
            .addMigrations(AppDatabase.MIGRATION_1_2)
            .addCallback(DatabaseInitializer())
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }
}
