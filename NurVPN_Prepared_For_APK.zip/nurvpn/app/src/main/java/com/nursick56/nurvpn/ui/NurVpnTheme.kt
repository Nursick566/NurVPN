package com.nursick56.nurvpn.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NurDarkColors = darkColorScheme(
    primary = Color(0xFF8B5CF6),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFFA78BFA),
    background = Color(0xFF0A0710),
    surface = Color(0xFF140F1F),
    surfaceVariant = Color(0xFF1A1329),
    onBackground = Color(0xFFEFEAFF),
    onSurface = Color(0xFFEFEAFF),
    onSurfaceVariant = Color(0xFF9A8DB8),
    error = Color(0xFFF87171)
)

@Composable
fun NurVpnTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NurDarkColors,
        content = content
    )
}
