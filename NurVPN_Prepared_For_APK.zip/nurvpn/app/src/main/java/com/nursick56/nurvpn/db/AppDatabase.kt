package com.nursick56.nurvpn.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import java.io.File

@Database(
    entities = [
        SchemaVersionEntity::class,
        SettingsEntity::class,
        HostConfigEntity::class,
        HostKeysEntity::class,
        PeerEntity::class,
        ConsumerConfigEntity::class,
        AuditEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun settingsDao(): SettingsDao
    abstract fun hostConfigDao(): HostConfigDao
    abstract fun peerDao(): PeerDao
    abstract fun consumerConfigDao(): ConsumerConfigDao
    abstract fun auditDao(): AuditDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                createBackup(db, oldVersion = 1)
                db.execSQL("ALTER TABLE peers ADD COLUMN blocked_reason TEXT")
                db.execSQL("ALTER TABLE peers ADD COLUMN expires_at INTEGER")
                db.execSQL("ALTER TABLE peers ADD COLUMN note TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS schema_version (" +
                        "version INTEGER NOT NULL, PRIMARY KEY(version))"
                )
                db.execSQL("INSERT OR REPLACE INTO schema_version(version) VALUES (2)")
            }
        }

        private fun createBackup(db: SupportSQLiteDatabase, oldVersion: Int) {
            try {
                db.query("PRAGMA wal_checkpoint(FULL)").close()
                val databaseFile = File(db.path)
                if (databaseFile.exists()) {
                    val backup = File(databaseFile.parentFile, "vpn.db.bak.$oldVersion")
                    databaseFile.copyTo(backup, overwrite = true)
                }
            } catch (_: Exception) {
                // Ошибка резервного копирования прерывает миграцию, чтобы не потерять исходную базу.
                throw IllegalStateException("Не удалось создать резервную копию базы данных.")
            }
        }
    }
}
