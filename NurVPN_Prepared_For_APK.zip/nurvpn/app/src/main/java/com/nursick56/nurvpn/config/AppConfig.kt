package com.nursick56.nurvpn.config

object AppConfig {
    const val APP_NAME = "NurVPN"
    const val APP_TAGLINE = "Твой дом в кармане"
    const val AUTHOR_NAME = "Nursick56"
    const val AUTHOR_TG = "https://t.me/repubr"
    const val AUTHOR_EMAIL = "repubr-comparison-AI@mail.ru"

    // Репозиторий ещё не создан; заполнить после публикации.
    const val GITHUB_REPO = "Nursick566/nurvpn"

    const val APP_VERSION = "1.0.0"
    const val VERSION_CODE = 1
    const val HOST_SERVICE_TYPE = "_nurvpn._udp."
    const val PBKDF2_ITERATIONS = 200_000
    const val PASSWORD_SALT_BYTES = 16
    const val NETWORK_TIMEOUT_SECONDS = 5L
}
